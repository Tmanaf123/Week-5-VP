package com.example.quizapp

data class Question(
    val text: String,
    val options: List<String>,
    val correctAnswerIndex: Int
)

data class QuizResultItem(
    val questionNumber: Int,
    val questionText: String,
    val userAnswer: String,
    val correctAnswer: String,
    val isCorrect: Boolean
)