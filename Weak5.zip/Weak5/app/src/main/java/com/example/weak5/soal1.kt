import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.weak5.Expense
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.weak5.R

@Composable
fun expensesscreen(expensevm:ExpenseViewModel= viewModel()) {
    val expenses by expensevm.expenses.collectAsState()
    val totalexp by expensevm.totalExpense.collectAsState()
    val errormsg by expensevm.errorMessage.collectAsState()

    var nameinput by remember{mutableStateOf("")}
    var amountinpt by remember{ mutableStateOf("") }

    var expensetoedit by remember{mutableStateOf<Expense?>(null)}
    var editminput by remember(expensetoedit){
        mutableStateOf(expensetoedit?.amount?.toString()?:"")
    }

    Column(
        modifier= Modifier.fillMaxSize().padding(16.dp)
    ) {
        Text(text="Expenses",fontSize =24.sp,fontWeight=FontWeight.Bold)
        Text(text= "Total Expense : Rp $totalexp",
            fontSize=14.sp,
            color =Color.Gray,
            modifier=Modifier.padding(bottom= 16.dp))

        Row(modifier =Modifier.fillMaxWidth(),
            verticalAlignment=Alignment.CenterVertically) {
            Column(modifier= Modifier.weight(1f)) {
                OutlinedTextField(value =nameinput,
                    onValueChange={nameinput =it},
                    label={ Text("Expense Name")},
                    modifier=Modifier.fillMaxWidth(),singleLine= true)

                Spacer(modifier=Modifier.height(8.dp))

                OutlinedTextField(
                    value= amountinpt,onValueChange={ amountinpt=it },
                    label={Text("Amount of Expense")},
                    modifier=Modifier.fillMaxWidth(),
                    keyboardOptions=KeyboardOptions(keyboardType= KeyboardType.Number),
                    isError= errormsg!= null,
                    singleLine =true
                )

                if (errormsg!= null&&expensetoedit ==null) {
                    Text(text=errormsg!!,color=Color.Red,
                        fontSize=12.sp, modifier= Modifier.padding(start=8.dp,top= 4.dp))
                }
            }
            Spacer(modifier=Modifier.width(8.dp))
            IconButton(
                onClick={
                    expensevm.addExpense(nameinput,amountinpt)
                    if(expensevm.errorMessage.value==null) {
                        nameinput =""
                        amountinpt=""
                    }
                },modifier= Modifier.background(Color(0xFFEEEEEE),shape=RoundedCornerShape(8.dp))) {
                Image(painter=painterResource(id= R.drawable.copycop),contentDescription="Add Expense")
            }
        }

        Spacer(modifier= Modifier.height(16.dp))

        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(expenses) { expitem->
                expenseitem(expense=expitem,
                    deleteclk={ expensevm.deleteExpense(expitem.id) },
                    editclk= {
                        expensetoedit=expitem
                        editminput= expitem.amount.toString()
                    })
            }
        }
    }

    if(expensetoedit!= null) {
        AlertDialog(
            onDismissRequest={expensetoedit=null },
            title={Text(text="Edit Amount")},
            text={
                Column {
                    OutlinedTextField(
                        value= editminput,
                        onValueChange={ editminput=it.filter(Char::isDigit)},
                        label={Text("New Amount") },
                        keyboardOptions= KeyboardOptions(keyboardType=KeyboardType.Number),
                        singleLine=true,isError=errormsg!=null
                    )
                    if(errormsg!= null) {
                        Text(text= errormsg!!,color=Color.Red,fontSize=12.sp)
                    }
                }
            },
            confirmButton= {
                TextButton(onClick= {
                    expensevm.updateExpenseAmount(expensetoedit!!.id,editminput)
                    if(expensevm.errorMessage.value== null) {
                        expensetoedit= null
                    }
                }) { Text("Save") }
            },
            dismissButton={
                TextButton(onClick={ expensetoedit=null }) { Text("Cancel") }
            })
    }
}

@Composable
fun expenseitem(expense:Expense,deleteclk:()->Unit,editclk:()-> Unit) {
    Card(modifier=Modifier.fillMaxWidth(),
        colors= CardDefaults.cardColors(containerColor=Color(0xFFE8EAF6))) {
        Row(modifier= Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement=Arrangement.SpaceBetween,
            verticalAlignment= Alignment.CenterVertically) {
            Column(modifier= Modifier.weight(1f)) {
                Text(text="Name : ${expense.name}",fontWeight=FontWeight.Bold)
                Text(text="Rp ${expense.amount}",color= Color.DarkGray)
            }
            Row {
                IconButton(onClick=editclk) {
                    Image(painter=painterResource(id=R.drawable.edit),contentDescription="Delete Icon")
                }
                IconButton(onClick=deleteclk) {
                    Image(painter=painterResource(id=R.drawable.trashdel),contentDescription="Delete Icon")
                }
            }
        }
    }
}

@Preview(showBackground=true)
@Suppress("ViewModelConstructorInComposable")
@Composable
fun expensescreenpreview() {
    MaterialTheme {
        expensesscreen(expensevm= ExpenseViewModel())
    }
}