package com.example.quizapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class QuizViewModel : ViewModel() {

    private val questionPool = listOf(
        Question(
            text = "Which letter does NOT appear in the name of any of the 50 US states?",
            options = listOf("Z", "Q", "X", "J"),
            correctAnswerIndex = 1
        ),
        Question(
            text = "What is the rarest naturally occurring element in the Earth's crust?",
            options = listOf("Francium", "Promethium", "Astatine", "Technetium"),
            correctAnswerIndex = 2
        ),
        Question(
            text = "Which country is home to the world's oldest university (Al-Qarawiyyin)?",
            options = listOf("Italy", "Egypt", "Morocco", "Greece"),
            correctAnswerIndex = 2
        ),
        Question(
            text = "Which bone in the human body is NOT connected to any other bone?",
            options = listOf("Stapes", "Hyoid", "Patella", "Clavicle"),
            correctAnswerIndex = 1
        ),
        Question(
            text = "What is the de facto capital city of Switzerland?",
            options = listOf("Zurich", "Geneva", "Bern", "Basel"),
            correctAnswerIndex = 2
        )
    )

    var currentScreen by mutableStateOf("START")
        private set

    var inputCount by mutableStateOf("")
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var activeQuestions by mutableStateOf<List<Question>>(emptyList())
        private set

    var currentIndex by mutableStateOf(0)
        private set

    var selectedOptionIndex by mutableStateOf<Int?>(null)
        private set

    var results by mutableStateOf<List<QuizResultItem>>(emptyList())
        private set
    fun onInputCountChange(newText: String) {
        inputCount = newText
        errorMessage = null
    }
    fun startQuiz() {
        val count = inputCount.toIntOrNull()
        if (count == null || count <= 0) {
            errorMessage = "Please enter a valid number"
            return
        }
        if (count > questionPool.size) {
            errorMessage = "Maximum is ${questionPool.size} questions"
            return
        }

        activeQuestions = questionPool.shuffled().take(count)
        currentIndex = 0
        selectedOptionIndex = null
        results = emptyList()
        currentScreen = "QUIZ"
    }

    fun selectOption(index: Int) {
        selectedOptionIndex = index
    }

    fun nextQuestion() {
        val selectedIdx = selectedOptionIndex ?: return
        val currentQ = activeQuestions[currentIndex]

        val item = QuizResultItem(
            questionNumber = currentIndex + 1,
            questionText = currentQ.text,
            userAnswer = currentQ.options[selectedIdx],
            correctAnswer = currentQ.options[currentQ.correctAnswerIndex],
            isCorrect = selectedIdx == currentQ.correctAnswerIndex
        )

        results = results + item
        selectedOptionIndex = null

        if (currentIndex + 1 < activeQuestions.size) {
            currentIndex++
        } else {
            currentScreen = "RESULT"
        }
    }
    fun restartQuiz() {
        inputCount = ""
        errorMessage = null
        currentScreen = "START"
    }
}