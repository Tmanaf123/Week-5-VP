package com.example.quizapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel


val PrimarySlateBlue = Color(0xFF4C5885)
val LightOptionBlue  = Color(0xFFE2E7FA)
val LightBackground  = Color(0xFFF8F9FE)

val DisabledButtonBg = Color(0xFFE6E8EF)
val DisabledTextClr = Color(0xFFB5B8C5)
val WrongAnswerRed   = Color(0xFFCF5252)


@Composable
fun QuizScreen(viewModel: QuizViewModel = viewModel()){
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = LightBackground
    ) {
        when (viewModel.currentScreen) {

            "START" -> {

                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Mini Quiz",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2C2C2C)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "How many questions do you want? (1 - 5)",
                        fontSize = 14.sp, color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    OutlinedTextField(
                        value = viewModel.inputCount,
                        onValueChange = { viewModel.onInputCountChange(it) },
                        label = { Text("Number of questions") },
                        isError = viewModel.errorMessage != null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = if (viewModel.errorMessage != null) Color.Red else PrimarySlateBlue,
                            unfocusedBorderColor = if (viewModel.errorMessage != null) Color.Red else Color.LightGray
                        )
                    )

                    if (viewModel.errorMessage != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = viewModel.errorMessage!!, color = Color.Red, fontSize = 12.sp,
                            modifier = Modifier.align(Alignment.Start)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    val isInputEmpty = viewModel.inputCount.isBlank()
                    Button(
                        onClick = { viewModel.startQuiz() },
                        enabled = !isInputEmpty,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimarySlateBlue,
                            disabledContainerColor = DisabledButtonBg
                        ),
                        shape = CircleShape
                    ) {
                        Text(
                            text = "Start Quiz", fontSize = 15.sp,
                            color = if (isInputEmpty) DisabledTextClr else Color.White
                        )
                    }
                }

            }

            "QUIZ" -> {
                val currentQ = viewModel.activeQuestions[viewModel.currentIndex]

                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(40.dp))

                    Text(
                        text = "Question ${viewModel.currentIndex + 1}",
                        fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = currentQ.text, fontSize = 15.sp, color = Color.Gray, textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    currentQ.options.forEachIndexed { index, optionText ->
                        val isSelected = viewModel.selectedOptionIndex == index
                        val bgColor = if (isSelected) PrimarySlateBlue else LightOptionBlue
                        val textColor = if (isSelected) Color.White else PrimarySlateBlue

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .height(48.dp)
                                .background(bgColor, shape = CircleShape)
                                .clickable { viewModel.selectOption(index) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = optionText, color = textColor, fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }


                    Spacer(modifier = Modifier.weight(1f))

                    val isOptionSelected = viewModel.selectedOptionIndex != null
                    Button(
                        onClick = { viewModel.nextQuestion() }, enabled = isOptionSelected,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimarySlateBlue,
                            disabledContainerColor = DisabledButtonBg
                        ), shape = CircleShape
                    ) {
                        Text(
                            text = "Next", fontSize = 15.sp,
                            color = if (isOptionSelected) Color.White else DisabledTextClr
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }


            "RESULT" -> {
                val total = viewModel.activeQuestions.size
                val correctCount = viewModel.results.count { it.isCorrect }
                val wrongResults = viewModel.results.filter { !it.isCorrect }

                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(40.dp))

                    Text(
                        text = "Quiz Finished!", fontSize = 22.sp,
                        fontWeight = FontWeight.Bold, color = Color(0xFF333333)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Your Score: $correctCount / $total", fontSize = 15.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(24.dp))

                    if (wrongResults.isEmpty()) {
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Perfect! No wrong answers.",
                                fontSize = 15.sp, color = PrimarySlateBlue
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(wrongResults) { item ->
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                                ) {
                                    Text(
                                        text = "Q${item.questionNumber}: ${item.questionText}",
                                        fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF333333)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = "Your Answer: ${item.userAnswer}", color = WrongAnswerRed, fontSize = 13.sp)
                                    Text(text = "Correct Answer: ${item.correctAnswer}", color = Color.Gray, fontSize = 13.sp)
                                    HorizontalDivider(
                                        modifier = Modifier.padding(top = 12.dp), color = Color(0xFFE5E7EB)
                                    )
                                }
                            }
                        }
                    }


                    Button(
                        onClick = { viewModel.restartQuiz() },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimarySlateBlue),
                        shape = CircleShape
                    ) {
                        Text(text = "Restart Quiz", fontSize = 15.sp, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
fun QuizScreenPreview() {
    QuizScreen()
}