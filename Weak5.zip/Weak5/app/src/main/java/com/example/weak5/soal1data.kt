package com.example.weak5

data class Expense(
    val id: String,
    val name: String,
    val amount: Int
)