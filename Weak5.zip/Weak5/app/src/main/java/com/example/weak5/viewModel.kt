import androidx.lifecycle.ViewModel
import com.example.weak5.Expense
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class ExpenseViewModel : ViewModel() {

    private val _expenses = MutableStateFlow<List<Expense>>(emptyList())
    val expenses: StateFlow<List<Expense>> = _expenses

    private val _totalExpense = MutableStateFlow(0)
    val totalExpense: StateFlow<Int> = _totalExpense

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    fun addExpense(name: String, amountString: String) {
        val amount = amountString.trim().toIntOrNull()

        if (amount == null || amount <= 0) {
            _errorMessage.value = "Amount must be greater than 0"
            return
        }

        val newExpense = Expense(
            id = UUID.randomUUID().toString(),
            name = name,
            amount = amount
        )

        _expenses.update { currentList -> currentList + newExpense }
        _errorMessage.value = null
        updateTotal()
    }

    fun updateExpenseAmount(expenseId: String, newAmountString: String) {
        val amount = newAmountString.toIntOrNull()

        if (amount == null || amount <= 0) {
            _errorMessage.value = "Amount must be greater than 0"
            return
        }

        _expenses.update { currentList ->
            currentList.map { expense ->
                if (expense.id == expenseId) {
                    expense.copy(amount = amount)
                } else {
                    expense
                }
            }
        }
        _errorMessage.value = null
        updateTotal() // for recalculating fter done
    }
    //todeelte thingy
    fun deleteExpense(expenseId: String) {
        _expenses.update { currentList ->
            currentList.filter { it.id != expenseId }
        }
        updateTotal()
    }
    fun clearError() { _errorMessage.value = null }
    // helper function thing so no repeated codes
    private fun updateTotal() {
        _totalExpense.value = _expenses.value.sumOf { it.amount }
    }
}